package com.gama.whiv.customerrepository.repositories;

import com.gama.whiv.customerrepository.entities.AccountData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountDataRepository extends JpaRepository<AccountData, Long> {
}

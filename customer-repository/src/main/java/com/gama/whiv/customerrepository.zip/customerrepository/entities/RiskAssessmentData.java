package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "risk_assessments")
public class RiskAssessmentData {
    @Id
    private Long customerId;
    private Double overallRiskScore;
    private Double geographicRiskScore;
    private Double transactionalRiskScore;
    private Double relationshipRiskScore;
    private Boolean sanctionsMatch;
    private Boolean pepMatch;
    private String adverseMediaDetails;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

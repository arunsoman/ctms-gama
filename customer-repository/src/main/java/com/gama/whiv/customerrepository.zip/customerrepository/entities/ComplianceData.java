package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "compliance_data")
public class ComplianceData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long complianceId;
    private Long customerId;
    private String complianceType;
    private String complianceStatus;
    private String auditDetails;
    private String reviewerComments;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

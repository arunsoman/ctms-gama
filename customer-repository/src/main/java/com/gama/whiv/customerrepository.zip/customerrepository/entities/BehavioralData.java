package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "behavioral_data")
public class BehavioralData {
    @Id
    private Long customerId;
    private Double averageTransactionFrequency;
    private Double averageTransactionValue;
    private String preferredChannels;
    private String usualLocations;
    private String typicalTransactionHours;
    private String unusualPatterns;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

package com.gama.whiv.customerrepository.repositories;

import com.gama.whiv.customerrepository.entities.ExternalData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ExternalDataRepository extends JpaRepository<ExternalData, Long> {
}

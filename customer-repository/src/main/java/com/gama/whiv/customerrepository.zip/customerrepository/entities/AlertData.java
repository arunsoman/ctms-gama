package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "alerts")
public class AlertData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long alertId;
    private Long customerId;
    private String alertType;
    private String alertStatus;
    private Double alertPriority;
    private String alertDetails;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

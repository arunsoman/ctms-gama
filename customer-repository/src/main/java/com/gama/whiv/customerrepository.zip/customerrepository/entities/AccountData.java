package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "accounts")
public class AccountData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;
    private Long customerId;
    private String accountNumber;
    private String accountType;
    private String accountStatus;
    private Timestamp creationDate;
    private Timestamp closureDate;
    private Double transactionLimit;
    private String linkedDevices;
    private Double overdraftLimit;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

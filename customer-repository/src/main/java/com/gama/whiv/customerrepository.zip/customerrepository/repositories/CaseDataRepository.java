package com.gama.whiv.customerrepository.repositories;

import com.gama.whiv.customerrepository.entities.CaseData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CaseDataRepository extends JpaRepository<CaseData, Long> {
}

package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "external_data")
public class ExternalData {
    @Id
    private Long customerId;
    private Boolean sanctionsListMatch;
    private Boolean watchlistMatch;
    private String adverseMediaLinks;
    private String thirdPartyRiskDetails;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}

package com.gama.whiv.customerrepository.entities;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Table(name = "transactions")
public class TransactionData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long transactionId;
    private Long customerId;
    private Timestamp transactionDateTime;
    private String transactionType;
    private Double transactionAmount;
    private String currency;
    private String senderDetails;
    private String receiverDetails;
    private String geolocation;
    private String channel;
    private String deviceInfo;
    private String flaggedStatus;
    private Double riskScore;
    private Timestamp createdAt;
    private Timestamp updatedAt;

    // Getters and Setters
}
